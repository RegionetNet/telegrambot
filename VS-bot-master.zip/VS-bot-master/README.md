Simple Telegram Bot

WebSite: http://good-developers.com/
Article: https://good-developers.com/prostoj-telegram-bot/
